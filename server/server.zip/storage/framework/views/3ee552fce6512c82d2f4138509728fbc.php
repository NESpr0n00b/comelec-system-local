<?php $__env->startSection('title', 'Override Candidate'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Override Candidate Result</span>
        <a href="<?php echo e(route('election.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Change the result for this candidate. Give a reason for overriding the results.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('record-candidate.update', $record_candidate->id)); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <span class="title">OVERRIDE DETAILS</span>
          <div class="fields">
            <div class="field input">
              <label for="reason">Reason</label>
              <textarea id="reason" type="text" name="reason" autocomplete="reason" autofocus><?php echo e($record_candidate->reason); ?></textarea>
            </div>
            <div class="field">
              <legend>Result</legend>
              <div class="radio">
                <div>
                  <label for="result_win">Win</label>
                  <input 
                    type="radio" 
                    name="is_elected" 
                    id="result_win" 
                    value="1"
                    <?php if($record_candidate->is_elected): ?>
                      checked
                    <?php endif; ?>
                  >
                </div>
                <div>
                  <label for="result_lose">Loss</label>
                  <input 
                    type="radio" 
                    name="is_elected" 
                    id="result_lose" 
                    value="0"
                    <?php if(!$record_candidate->is_elected): ?>
                      checked
                    <?php endif; ?>
                  >
                </div>
              </div>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Override Result</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/election-candidates/edit.blade.php ENDPATH**/ ?>