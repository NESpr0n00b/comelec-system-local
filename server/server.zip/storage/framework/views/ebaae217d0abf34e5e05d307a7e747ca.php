<?php $__env->startSection('title', 'Student Accounts List'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Student Accounts List</span>
      </div>
      <span class="description">Oversee and manage the mobile accounts of the students.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <div class="actions">
          <select class="filter" name="filter" onchange="filter(this.value)">
            <option 
              value=""
              <?php if(!request('filter')): ?>
                selected
              <?php endif; ?>
            >
              Select Status
            </option>
            <option 
              value="v"
              <?php if(request('filter') == 'v'): ?>
                selected
              <?php endif; ?>
            >
              Awaiting Verification
            </option>
            <option 
              value="a"
              <?php if(request('filter') == 'a'): ?>
                selected
              <?php endif; ?>
            >
              Active
            </option>
          </select>
          <form 
            class="search"
            action="<?php echo e(route('student-accounts.search')); ?>"
          >
            <div class="search__group">
              <i class="fa-solid fa-magnifying-glass"></i>
              <input type="text" name="query" placeholder="Search...">
              <input 
                type="hidden" 
                name="filter"
                value="<?php echo e(request('filter') ?? ''); ?>"
              >
            </div>
            <i class="fa-solid fa-xmark search__exit"></i>
          </form>
        </div>
        <table>
          <thead>
            <tr>
              <th class="col1">Name</th>
              <th class="col2">ID</th>
              <th class="col4">Status</th>
              <th class="col5">Date Created</th>
              <th class="col6">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="col1">
                  <?php echo e($account->full_name); ?>

                </td>
                <td class="col2">
                  <?php echo e($account->student_id); ?>

                </td>
                <td class="col4">
                  <?php echo e([
                      'v' => 'Awaiting Verification',
                      'a' => 'Active',
                      'i' => 'Inactive',
                    ][$account->status]); ?>

                </td>
                <td class="col4">
                  <?php echo e($account->created_at); ?>

                </td>
                <td class="col5 flex-end">
                  <?php if (! ($account->status === 'a')): ?>
                    <button 
                      class="secondary" 
                      id="verify-btn"
                      onclick="verify(<?php echo e($account->id); ?>)"
                    >
                      <i class="fa-solid fa-check"></i>
                    </button>
                  <?php endif; ?>
                  <a href="<?php echo e(route('student-accounts.edit', $account->id)); ?>">
                    <button class="secondary">
                      <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                  </a>
                  <button 
                    class="secondary" 
                    id="delete-btn"
                    onclick="deleteAccount(<?php echo e($account->id); ?>)"
                  >
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php echo e($accounts->links()); ?>


  </div>

  <script>
    function verify(id) {
      axios.post(
        route('student-accounts.verify', id)
      ).then(() => window.location.reload());
    }

    function deleteAccount(id) {
      axios.delete(
        route('student-accounts.destroy', id)
      ).then(() => window.location.reload());
    }

    function filter(value) {
      const urlParams = new URLSearchParams(window.location.search)?.get('query') ?? '';
      window.location.href = `
        /student-accounts/search?query=${urlParams}&filter=${value}
      `;
    }
  </script>
  <!-- JS Link -->
  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/student-accounts/index.blade.php ENDPATH**/ ?>