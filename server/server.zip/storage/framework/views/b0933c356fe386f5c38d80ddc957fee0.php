<?php $__env->startSection('title', 'Edit Position'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Edit Position</span>
        <a href="<?php echo e(route('positions.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Edit a position. Set what college the position applies to and the number of winning candidates for that position.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('positions.update', $position->id)); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <span class="title">BASIC INFORMATION</span>
          <div class="fields">
            <div class="group">
              <div class="field">
                <label for="name">Position Name</label>
                <input id="name" type="text" class="form-control" name="position_name" required autocomplete="name" value="<?php echo e($position->position_name); ?>" autofocus>
              </div>
              <div class="field">
                <label for="candidate_elect_num">Number of Candidates to be Elected</label>
                <input id="candidate_elect_num" type="text" class="form-control" name="num_of_elects" required autocomplete="candidate_elect_num" value="<?php echo e($position->num_of_elects); ?>">
              </div>
            </div>
            <div class="group">
              <div class="field input">
                <label for="all_colleges">All Colleges</label>
                <input 
                  id="all_colleges" 
                  type="checkbox" 
                  name="is_for_all" 
                  autocomplete="all_colleges"
                  <?php if($position->is_for_all): ?>
                    checked
                  <?php endif; ?>
                >
              </div>
              <div class="field input">
                <label for="college">College</label>
                <input id="college" type="text" name="college" autocomplete="college" value="<?php echo e($position->college); ?>">
              </div>
            </div>
            <div class="field input">
              <label for="description">Description</label>
              <textarea id="description" type="text" name="description" autocomplete="description" value="<?php echo e($position->description); ?>"></textarea>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Update Position</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/positions-list/edit.blade.php ENDPATH**/ ?>