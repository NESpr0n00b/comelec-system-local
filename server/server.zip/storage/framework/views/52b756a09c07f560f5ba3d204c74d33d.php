<?php $__env->startSection('title', 'Add Candidate'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Add Candidate</span>
        <a href="<?php echo e(route('candidates.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Add a candidate by student ID. Set the position and party name of the candidate.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('candidates.store')); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <span class="title">BASIC INFORMATION</span>
          <div class="fields">
            <div class="group">
              <div class="field">
                <label for="student_id">Student ID</label>
                <input id="student_id" type="text"  name="student_id" required autocomplete="student_id" autofocus>
              </div>
              <div class="field readonly">
                <label for="name">Name</label>
                <input id="name" type="text" name="name" required autocomplete="name" readonly>
              </div>
            </div>
            <div class="group">
              <div class="field input">
                <label for="position">Position</label>
                <select name="position_id" id="position">
                  <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                      value="<?php echo e($position->id); ?>"
                    >
                      <?php echo e($position->position_name); ?>

                    </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              <div class="field input">
                <label for="party_name">Party Name</label>
                <input id="party_name" type="text" name="party_name" autocomplete="party_name">
              </div>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Add Student</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/candidates-list/create.blade.php ENDPATH**/ ?>