<?php $__env->startSection('title', 'Announcement Editor'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container short">
        
        <div class="page__header">
            <div class="group">
                <span class="group__title">Announcement Editor</span>
            </div>
            <span class="description">Edit the announcement page in the mobile application. Enter your desired announcement on the embedded article field.</span>
        </div>
        <div class="content">
            <div class="content__row">
                <form 
                    class="modify" 
                    action="<?php echo e(route('announcements.update', 1)); ?>" 
                    method="POST"
                >
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <span class="title">PAGE INFORMATION</span>
                    <div class="fields">
                        <div class="field full">
                            <label for="article">Embedded Article</label>
                            <textarea id="article" type="text" name="text" required autocomplete="article"><?php echo e($announcement->text); ?></textarea>
                        </div>
                    </div>
                    <div class="page__actions">
                        <button type="submit" class="tertiary wide">Update Announcement</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/announcement-editor/index.blade.php ENDPATH**/ ?>