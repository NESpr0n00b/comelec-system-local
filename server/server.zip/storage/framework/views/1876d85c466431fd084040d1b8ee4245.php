<?php $__env->startSection('title', 'Positions List'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Positions List</span>
      </div>
      <span class="description">Edit the officer positions of the Student Government.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <div class="actions">
          <div class="actions__btn">
            <a href="<?php echo e(route('positions.create')); ?>">
              <button class="primary">
                <i class="fa-regular fa-square-plus"></i>
                <span class="name">Add Position</span>
              </button>
            </a>
          </div>
          <form 
            class="search"
            action="<?php echo e(route('positions.search')); ?>"
          >
            <div class="search__group">
              <i class="fa-solid fa-magnifying-glass"></i>
              <input type="text" name="query" placeholder="Search...">
            </div>
            <i class="fa-solid fa-xmark search__exit"></i>
          </form>
        </div>
        <table class="position">
          <thead>
            <tr>
              <th class="col1">Position Name</th>
              <th class="col2">ID</th>
              <th class="col3">Description</th>
              <th class="col4">Colleges</th>
              <th class="col5">Number of Candidates to be Elected</th>
              <th class="col6">Actions</th>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="col1"><?php echo e($position->position_name); ?></td>
                  <td class="col2"><?php echo e($position->id); ?></td>
                  <td class="col3"><?php echo e($position->description); ?></td>
                  <td class="col4">
                    <?php echo e($position->is_for_all 
                      ? 'All Colleges'
                      : $position->college); ?>

                  </td>
                  <td class="col5"><?php echo e($position->num_of_elects); ?></td>
                  <td class="col6">
                    <a href="<?php echo e(route('positions.edit', $position->id)); ?>">
                      <button class="secondary">
                        <i class="fa-solid fa-pen-to-square"></i>
                      </button>
                    </a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php echo e($positions?->links()); ?>


  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/positions-list/index.blade.php ENDPATH**/ ?>