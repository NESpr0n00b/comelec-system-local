<?php $__env->startSection('title', 'Permitted Networks'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Network List</span>
      </div>
      <span class="description">Edit the list of networks students are allowed to connect to be able to vote.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <div class="actions">
          <div class="actions__btn">
            <a href="<?php echo e(route('networks.create')); ?>">
              <button class="primary">
                <i class="fa-regular fa-square-plus"></i>
                <span class="name">Add Network</span>
              </button>
            </a>
          </div>
          <form 
            class="search"
            action="<?php echo e(route('networks.search')); ?>"
          >
            <div class="search__group">
              <i class="fa-solid fa-magnifying-glass"></i>
              <input type="text" name="query" placeholder="Search...">
            </div>
            <i class="fa-solid fa-xmark search__exit"></i>
          </form>
        </div>
        <table>
          <thead>
            <tr>
              <th class="col1">Name</th>
              <th class="col2">ID</th>
              <th class="col5">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td class="col1"><?php echo e($network->name); ?></td>
                  <td class="col2"><?php echo e($network->id); ?></td>
                  <td class="col5">
                    <a href="<?php echo e(route('networks.edit', $network->id)); ?>">
                      <button class="secondary">
                        <i class="fa-solid fa-pen-to-square"></i>
                      </button>
                    </a>
                    <button 
                      class="secondary" 
                      id="delete-btn"
                      onclick="deleteNetwork(<?php echo e($network->id); ?>)"
                    >
                      <i class="fa-solid fa-trash"></i>
                    </button>
                  </td>
              </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php echo e($networks?->links()); ?>


  </div>

  <script>
    function deleteNetwork(id) {
      axios.delete(
        route('networks.destroy', id),
      ).then(() => window.location.reload());
    }
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/permitted-networks/index.blade.php ENDPATH**/ ?>