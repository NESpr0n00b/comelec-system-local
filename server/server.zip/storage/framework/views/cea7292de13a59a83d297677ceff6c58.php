<?php $__env->startSection('title', 'My Profile'); ?>

<?php $__env->startSection('content'); ?>

<?php ($isAdmin = in_array(Auth::user()->role, ['s', 'a'])); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <?php if($isAdmin): ?>
          <span class="group__title">Administrator's Account</span>
          <span class="group__description">Edit your profile and other COMELEC accounts.</span>
        <?php else: ?>
          <span class="group__title">My Account</span>
          <span class="group__description">Edit your profile.</span>
        <?php endif; ?>
      </div>
      <div class="tab">
        <a href="<?php echo e(route('account.profile')); ?>">
          <span class="selector active">My Profile</span>
        </a>
        <?php if($isAdmin): ?>
          <a href="<?php echo e(route('account.admin.index')); ?>">
            <span class="selector">Accounts</span>
          </a>
        <?php endif; ?>
      </div>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('account.update')); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <span class="title">MY PROFILE</span>
          <span class="introduction">
            Hello, <?php echo e(Auth::user()->username); ?>!
          </span>
          <div class="fields">
            <div class="group">
              <div class="field input">
                <label for="student_id">Student ID</label>
                <input id="student_id" type="text" name="student_id" required autocomplete="student_id" autofocus value="<?php echo e(Auth::user()->student_id); ?>">
              </div>
              <div class="field input">
                <label for="username">Username</label>
                <input id="username" type="text" name="username" required autocomplete="username" value="<?php echo e(Auth::user()->username); ?>">
              </div>
            </div>
            <div class="field button">
              <button class="primary wide" type="submit">Save Changes</button>
            </div>
          </div>
        </form>
      </div>
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('account.update')); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <span class="title">CHANGE YOUR PASSWORD</span>
          <div class="fields">
            <div class="group">
              <div class="field input">
                <label for="password">New Password</label>
                <input id="password" type="password" name="password" required autocomplete="password">
              </div>
              <div class="field input">
                <label for="confirm_password">Re-enter Password</label>
                <input id="confirm_password" type="password" name="password_confirm" required autocomplete="confirm_password">
              </div>
            </div>
            <div class="field button">
              <button class="primary wide" type="submit">Confirm</button>
            </div>
          </div>
        </form>
      </div>
      <div class="content__row">
        <div class="settings">
          <span class="title">SETTINGS</span>
            <div class="group">
              <span class="name">Would you like to delete your account?</span>
              <div class="actions">
                <button class="primary wide" id="account-delete-btn" onclick="deleteAccount()">Delete Account</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script>
    function deleteAccount() {
      axios.delete(
        route('account.destroy'),
      ).then(() => window.location.href = route('login'));
    }
  </script>

  <!-- JS Link -->
  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/accounts-profile/index.blade.php ENDPATH**/ ?>