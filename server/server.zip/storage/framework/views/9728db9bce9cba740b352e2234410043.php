<div class="menu user">
 <div class="menu__content">
  <div class="actions">
   <a href="<?php echo e(route('account.profile')); ?>">
    <span class="name">My Profile</span>
    <i class="fa-solid fa-user-large"></i>
   </a>
   <a onclick="logout()" style="cursor: pointer">
    <span class="name">Sign Out</span>
    <i class="fa-solid fa-arrow-right-from-bracket"></i>
   </a>
  </div>
 </div>
</div>

<script>
  function logout() {
    axios.post(
      route('logout'),
    ).then(() => window.location.href = route('login'));
  }
</script><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/layouts/components/menus.blade.php ENDPATH**/ ?>