<?php $__env->startSection('title', 'Edit Student Account'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Edit Student Account</span>
        <a href="<?php echo e(route('student-accounts.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Edit student account information. Change the status to active to allow the student to vote.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('student-accounts.update', $account->id)); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <span class="title">ACCOUNT CREDENTIALS</span>
          <div class="fields">
            <div class="group">
              <div class="field">
                <label for="name">Name</label>
                <input id="name" type="text" name="full_name" required autocomplete="name" value="<?php echo e($account->full_name); ?>" autofocus>
              </div>
              <div class="field">
                <label for="password">New Password</label>
                <input id="password" type="password" name="password" autocomplete="password">
              </div>
            </div>
            <div class="field input single">
              <label for="student_id">Status</label>
              <select name="status">
                <option value="">Select Status</option>
                <option 
                  value="a"
                  <?php if($account->status === 'a'): ?>
                    selected
                  <?php endif; ?>
                >
                  Active
                </option>
                <option 
                  value="i"
                  <?php if($account->status === 'i'): ?>
                    selected
                  <?php endif; ?>
                >
                  Inactive
                </option>
              </select>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/student-accounts/edit.blade.php ENDPATH**/ ?>