<?php $__env->startSection('title', 'Election Manager'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Election Records List</span>
      </div>
      <span class="description">Records of active and past elections. Create an active election record to start an election period.Access an active election to manage it.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <div class="actions">
          <?php if (! (Auth::user()->role === 'c')): ?> 
            <div class="actions__btn">
              <a href="<?php echo e(route('election.create')); ?>">
                <button class="primary">
                  <i class="fa-solid fa-file-import"></i>
                  <span class="name">Create Record</span>
                </button>
              </a>
            </div>
          <?php endif; ?>
          <select class="filter" name="filter" onchange="filter(this.value)">
            <option 
              value=""
              <?php if(!request('filter')): ?>
                selected
              <?php endif; ?>
            >
              Select Status
            </option>
            <option 
              value="r"
              <?php if(request('filter') == 'r'): ?>
                selected
              <?php endif; ?>
            >
              Archived
            </option>
            <option 
              value="f"
              <?php if(request('filter') == 'f'): ?>
                selected
              <?php endif; ?>
            >
              Final
            </option>
            <option 
              <?php if(request('filter') == 'c'): ?>
                selected
              <?php endif; ?>
              value="c"
            >
              Cancelled
            </option>
          </select>
          <form class="search" action="<?php echo e(route('election.search')); ?>">
            <div class="search__group">
              <i class="fa-solid fa-magnifying-glass"></i>
              <input type="text" name="query" placeholder="Search...">
              <input 
                type="hidden" 
                name="filter"
                value="<?php echo e(request('filter') ?? ''); ?>"
              >
            </div>
            <i class="fa-solid fa-xmark search__exit"></i>
          </form>
        </div>
        <table>
          <thead>
            <tr>
              <th class="col1">Record Name</th>
              <th class="col2">ID</th>
              <th class="col3">Election Details</th>
              <th class="col4">Status</th>
              <th class="col4">Start Time</th>
              <th class="col5">End Time</th>
            </tr>
          </thead>
          <tbody class="wide">
              <?php $__currentLoopData = $elections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $election): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                  onclick="electionManager(<?php echo e($election->id); ?>)"
                  style="cursor: pointer;"
                >
                  <td class="col1"><?php echo e($election->name); ?></td>
                  <td class="col2"><?php echo e($election->id); ?></td>
                  <td class="col3"><?php echo e($election->description); ?></td>
                  <td class="col4"><?php echo e([
                      'a' => 'Active',
                      'c' => 'Canceled',
                      'f' => 'Final',
                      'r' => 'Archived',
                    ][$election->status]); ?></td>
                  <td class="col4"><?php echo e($election->start_time); ?></td>
                  <td class="col5"><?php echo e($election->end_time); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php echo e($elections?->links()); ?>

  </div>

  <script>
    function electionManager(id) {
      window.location.href = route('election.candidates', id);
    }

    function filter(value) {
      const urlParams = new URLSearchParams(window.location.search)?.get('query') ?? '';
      window.location.href = `
        /election/search?query=${urlParams}&filter=${value}
      `;
    }
  </script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/election-manager/index.blade.php ENDPATH**/ ?>