<?php $__env->startSection('title', 'Add Account'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Add Account</span>
        <a href="<?php echo e(route('account.admin.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Create a new COMELEC account.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('account.admin.store')); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <span class="title">BASIC INFORMATION</span>
          <div class="fields">
            <div class="group">
              <div class="field input">
                <label for="student_id">Student ID</label>
                <input id="student_id" type="text" name="student_id" required autocomplete="student_id" autofocus>
              </div>
              <div class="field input">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" required autocomplete="password">
              </div>
            </div>
            <div class="group">
              <div class="field input">
                <label for="username">Username</label>
                <input id="username" type="text" name="username" required autocomplete="username">
              </div>
              <div class="field short">
                <label for="user_role">User Role</label>
                <select name="role" id="user_role">
                  <option value="0">Select Role</option>
                  <option value="s">Super Admin</option>
                  <option value="a">Admin</option>
                  <option value="m">Student Accounts Manager</option>
                  <option value="c">Commissioner</option>
                  <option value="p">Poll Workers</option>
                </select>
              </div>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Add Account</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/accounts-admin/create.blade.php ENDPATH**/ ?>