<?php $__env->startSection('title', 'Candidates List'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="page__header">
      <div class="group">
        <span class="group__title">Candidates List</span>
      </div>
      <span class="description">Current candidates that students can vote for. The candidates can be edited before creating an election record.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <div class="actions">
          <div class="actions__btn">
            <a href="<?php echo e(route('candidates.create')); ?>">
              <button class="primary">
                <i class="fa-regular fa-square-plus"></i>
                <span class="name">Add Candidate</span>
              </button>
            </a>
            <button 
              class="secondary"
              onclick="deleteAll()"
            >
              <i class="fa-solid fa-trash"></i>
              <span class="name">Delete All Candidates</span>
            </button>
          </div>
          <a href="<?php echo e(route('candidates.archive')); ?>">
            <button class="secondary">
              <i class="fa-solid fa-eye"></i>
              <span class="name">View Archived Candidates</span>
            </button>
          </a>
          <form 
            class="search"
            action="<?php echo e(route('candidates.search')); ?>"
          >
            <div class="search__group">
              <i class="fa-solid fa-magnifying-glass"></i>
              <input type="text" name="query" placeholder="Search...">
            </div>
            <i class="fa-solid fa-xmark search__exit"></i>
          </form>
        </div>
        <table>
          <thead>
            <tr>
              <th class="col1">Name</th>
              <th class="col2">ID</th>
              <th class="col3">Party Name</th>
              <th class="col4">Position</th>
              <th class="col4">Date Created</th>
              <th class="col5">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="col1">
                  <?php echo e($candidate->student->full_name); ?>

                </td>
                <td class="col2">
                  <?php echo e($candidate->student->student_id); ?>

                </td>
                <td class="col3">
                  <?php echo e($candidate->party_name); ?>

                </td>
                <td class="col4">
                  <?php echo e($candidate->position->position_name); ?>

                </td>
                <td class="col4">
                  <?php echo e($candidate->created_at); ?>

                </td>
                <td class="col5">
                  <a href="<?php echo e(route('candidates.edit', $candidate->id)); ?>">
                    <button class="secondary">
                      <i class="fa-solid fa-pen-to-square"></i>
                    </button>
                  </a>
                  <button 
                    class="secondary" 
                    id="delete-btn"
                    onclick="deleteCandidate(<?php echo e($candidate->id); ?>)"
                  >
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php echo e($candidates->links()); ?>


  </div>

  <script>
    function deleteCandidate(id) {
      axios.delete(
        route('candidates.destroy', id)
      ).then(() => window.location.reload());
    }

    function deleteAll() {
      axios.post(
        route('candidates.destroy-all')
      ).then(() => window.location.reload());
    }
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/candidates-list/index.blade.php ENDPATH**/ ?>