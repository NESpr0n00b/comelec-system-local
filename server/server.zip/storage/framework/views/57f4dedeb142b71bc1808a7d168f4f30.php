<?php $__env->startSection('title', 'Edit Student'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Edit Student</span>
        <a href="<?php echo e(route('master-list.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Edit a student information. Set the student to be enrolled or unenrolled.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('students.update', $student->student_id)); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <span class="title">BASIC INFORMATION</span>
          <div class="fields">
            <div class="field full">
              <label for="full_name">Full Name</label>
              <input id="full_name" type="text" name="full_name" required autocomplete="full_name" value="<?php echo e($student->full_name); ?>">
            </div>
            <div class="group">
              <div class="field input">
                <label for="student_id">Student ID</label>
                <input id="student_id" type="text" name="student_id" required autocomplete="student_id" readonly value="<?php echo e($student->student_id); ?>">
              </div>
              <div class="field input">
                <label for="college">College</label>
                <input id="college" type="text" name="college" required autocomplete="college" value="<?php echo e($student->college); ?>">
              </div>
            </div>
            <div class="group">
              <div class="field input">
                <label for="status">Enrolled</label>
                <input 
                  id="status" 
                  type="checkbox" 
                  name="is_enrolled" 
                  autocomplete="enrolled"
                  <?php if($student->is_enrolled): ?>
                    checked
                  <?php endif; ?>
                >
              </div>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/master-list/edit.blade.php ENDPATH**/ ?>