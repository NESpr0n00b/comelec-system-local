<?php $__env->startSection('title', 'Create Permitted Network'); ?>

<?php $__env->startSection('content'); ?>

  <div class="container short">
    
    <div class="page__header">
      <div class="group">
        <span class="group__title">Add Network</span>
        <a href="<?php echo e(route('networks.index')); ?>">
          <button class="primary bold">
            <i class="fa-solid fa-arrow-left-long"></i>
            Go Back
          </button>
        </a>
      </div>
      <span class="description">Enter the name of the network that students can connect to to vote.</span>
    </div>
    <div class="content">
      <div class="content__row">
        <form 
          class="modify" 
          action="<?php echo e(route('networks.store')); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <span class="title">BASIC INFORMATION</span>
          <div class="fields">
            <div class="field single">
              <label for="name">Network Name</label>
              <input id="name" type="text" name="name" required autocomplete="network_name" autofocus>
            </div>
          </div>
          <div class="page__actions">
            <button type="submit" class="tertiary wide">Add Network</button>
          </div>
        </form>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/frontend/permitted-networks/create.blade.php ENDPATH**/ ?>