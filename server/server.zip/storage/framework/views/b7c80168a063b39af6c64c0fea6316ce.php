<?php ($role = Auth::user()->role); ?>

<div class="header">
  <div class="header__left">
    <div class="logo">
      <img src="<?php echo e(asset('images/comelec_logo.png')); ?>" style="width: 2em">
    </div>
    
      <ul class="nav">
        <?php if(in_array($role, ['p'])): ?>
          <li>
            <a href="<?php echo e(route('access-code.index')); ?>">Access Code Generator</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a', 'm', 'c'])): ?>
          <li>
            <a href="<?php echo e(route('master-list.index')); ?>">Student Master List</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a', 'm'])): ?>
          <li>
            <a href="<?php echo e(route('student-accounts.index')); ?>">Students Accounts</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a', 'c'])): ?>
          <li>
            <a href="<?php echo e(route('candidates.index')); ?>">Candidates List</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a', 'c'])): ?>
          <li>
            <a href="<?php echo e(route('election.index')); ?>">Election Manager</a>
          </li>
        <?php endif; ?>
        
        <?php if(in_array($role, ['s', 'a', 'c'])): ?>
          <li>
            <a href="<?php echo e(route('announcements.index')); ?>">Announcement Editor</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a', 'c'])): ?>
          <li>
            <a href="<?php echo e(route('message-editor.index')); ?>">Message Editor</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a'])): ?>
          <li>
            <a href="<?php echo e(route('positions.index')); ?>">Positions List</a>
          </li>
        <?php endif; ?>
        <?php if(in_array($role, ['s', 'a'])): ?>
          <li>
            <a href="<?php echo e(route('networks.index')); ?>">Networks List</a>
          </li>
        <?php endif; ?>
      </ul>
  </div>
  <div class="header__right" id="user-btn">
    <div class="header__separator"></div>
    <div class="details">
      <span class="details__name">
        <?php echo e(Auth::user()->username); ?>

      </span>
      <span class="details__role">
        <?php echo e([
            's' => 'Super Admin',
            'a' => 'Admin',
            'm' => 'Student Accounts Manager',
            'c' => 'Commissioner',
            'p' => 'Poll Worker',
          ][$role]); ?>

      </span>
    </div>
    <div class="group">
      <i class="fa-solid fa-circle-user group__icon"></i>
      <i class="fa-solid fa-angle-up group__icon" id="user-angle"></i>
    </div>
  </div>
</div><?php /**PATH C:\Users\USER\Documents\College Files\3rd Year\Commissions\E-voting system\comelec-system\server\resources\views/layouts/inc/header.blade.php ENDPATH**/ ?>