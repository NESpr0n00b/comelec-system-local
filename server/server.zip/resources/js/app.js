import './bootstrap';
import './frontend';

import.meta.glob([
  '../assets/images/**',
]);