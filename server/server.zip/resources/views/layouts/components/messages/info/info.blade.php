<div class="message info">
 <div class="group">
  <i class="fa-solid fa-circle-info"></i>
  <div class="column">
   <span class="title">Info</span>
   <span class="description">The developers have updated new things. Please check the patch notes!</span>
  </div>
 </div>
 <button class="secondary" id="exit-message">
  <i class="fa-solid fa-xmark"></i>
 </button>
</div>