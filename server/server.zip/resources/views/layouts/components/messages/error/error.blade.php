<div class="message error">
 <div class="group">
  <i class="fa-solid fa-ban"></i>
  <div class="column">
   <span class="title">Error</span>
   <span class="description">{{ $message }}</span>
  </div>
 </div>
 <button class="secondary" id="exit-message">
  <i class="fa-solid fa-xmark"></i>
 </button>
</div>
