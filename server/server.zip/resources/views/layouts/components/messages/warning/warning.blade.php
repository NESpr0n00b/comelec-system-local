<div class="message warning">
 <div class="group">
  <i class="fa-solid fa-triangle-exclamation"></i>
  <div class="column">
   <span class="title">Warning</span>
   <span class="description">Looks like something went wrong to the database. Try again.</span>
  </div>
 </div>
 <button class="secondary" id="exit-message">
  <i class="fa-solid fa-xmark"></i>
 </button>
</div>