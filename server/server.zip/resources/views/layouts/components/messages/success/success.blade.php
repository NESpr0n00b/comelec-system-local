<div class="message success">
 <div class="group">
  <i class="fa-solid fa-check"></i>
  <div class="column">
   <span class="title">Success</span>
   <span class="description">The data row was successfully deleted.</span>
  </div>
 </div>
 <button class="secondary" id="exit-message">
  <i class="fa-solid fa-xmark"></i>
 </button>
</div>