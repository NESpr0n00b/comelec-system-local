 <footer>
  <i class="fa-solid fa-copyright"></i>
  <span class="description">COMELEC 2023 | All Rights Reserved | Version
  </span>
 </footer>